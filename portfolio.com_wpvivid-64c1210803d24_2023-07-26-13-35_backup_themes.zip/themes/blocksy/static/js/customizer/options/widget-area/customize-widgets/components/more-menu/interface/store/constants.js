/**
 * The identifier for the data store.
 *
 * @type {string}
 */
export const STORE_NAME = 'core/interface'
