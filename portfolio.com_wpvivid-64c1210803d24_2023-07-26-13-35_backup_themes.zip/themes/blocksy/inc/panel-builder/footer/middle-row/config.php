<?php

$config = [
	'name' => __('Middle Row', 'blocksy'),
	'typography_keys' => ['footerWidgetsTitleFont', 'footerWidgetsFont'],
];

